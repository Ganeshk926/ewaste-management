package com.ewaste.enums;
public enum PaymentStatus { PENDING, SUCCESS, FAILED }
