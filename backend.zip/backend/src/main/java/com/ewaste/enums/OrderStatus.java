package com.ewaste.enums;
public enum OrderStatus { ORDERED, PACKED, SHIPPED, DELIVERED, CANCELLED }
