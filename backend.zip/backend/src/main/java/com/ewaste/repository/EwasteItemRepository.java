package com.ewaste.repository;
import com.ewaste.entity.EwasteItem;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EwasteItemRepository extends JpaRepository<EwasteItem,Long> {}
