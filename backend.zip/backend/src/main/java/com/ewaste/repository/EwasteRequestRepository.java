package com.ewaste.repository;
import com.ewaste.entity.EwasteRequest;
import com.ewaste.enums.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EwasteRequestRepository extends JpaRepository<EwasteRequest,Long> {
    List<EwasteRequest> findByUserId(Long userId);
    List<EwasteRequest> findByStatus(RequestStatus status);
    List<EwasteRequest> findByAssignedWorkerId(Long workerId);
    long countByStatus(RequestStatus status);
}
