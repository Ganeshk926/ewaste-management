package com.ewaste.repository;
import com.ewaste.entity.Order;
import com.ewaste.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface OrderRepository extends JpaRepository<Order,Long> {
    List<Order> findByUserIdOrderByCreatedAtDesc(Long userId);
    long countByOrderStatus(OrderStatus status);
}
