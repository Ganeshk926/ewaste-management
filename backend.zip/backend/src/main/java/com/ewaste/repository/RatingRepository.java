package com.ewaste.repository;
import com.ewaste.entity.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;
public interface RatingRepository extends JpaRepository<Rating,Long> {
    List<Rating> findByWorkerId(Long workerId);
    Optional<Rating> findByRequestId(Long requestId);
    @Query("SELECT AVG(r.rating) FROM Rating r WHERE r.workerId = :workerId")
    Double avgRatingByWorkerId(Long workerId);
    long countByWorkerId(Long workerId);
}
