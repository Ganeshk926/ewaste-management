package com.ewaste.repository;
import com.ewaste.entity.EwasteRequestItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EwasteRequestItemRepository extends JpaRepository<EwasteRequestItem,Long> {
    List<EwasteRequestItem> findByRequestId(Long requestId);
}
