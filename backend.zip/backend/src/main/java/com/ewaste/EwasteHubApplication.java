package com.ewaste;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class EwasteHubApplication {
    public static void main(String[] args) { 
    	SpringApplication.run(EwasteHubApplication.class, args);
    }
}
