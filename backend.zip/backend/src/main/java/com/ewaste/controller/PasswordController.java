package com.ewaste.controller;
import com.ewaste.dto.ApiResponse;
import com.ewaste.dto.pswd.*;
import com.ewaste.service.PasswordService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/password")
public class PasswordController {
    private final PasswordService svc;
    public PasswordController(PasswordService s){svc=s;}
    @PostMapping("/forgot") public ResponseEntity<ApiResponse<String>> forgot(@Valid @RequestBody ForgotPasswordRequest r){return ResponseEntity.ok(ApiResponse.ok(svc.generateOtp(r.getEmail())));}
    @PostMapping("/verify-otp") public ResponseEntity<ApiResponse<String>> verify(@RequestBody VerifyOtpRequest r){return ResponseEntity.ok(ApiResponse.ok(svc.verifyOtp(r.getEmail(),r.getOtp())));}
    @PostMapping("/reset") public ResponseEntity<ApiResponse<String>> reset(@RequestBody ResetPasswordRequest r){return ResponseEntity.ok(ApiResponse.ok(svc.resetPassword(r.getEmail(),r.getNewPassword())));}
}
