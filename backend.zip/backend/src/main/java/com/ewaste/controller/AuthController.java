package com.ewaste.controller;

import com.ewaste.dto.*;
import com.ewaste.entity.User;
import com.ewaste.entity.Worker;
import com.ewaste.exception.CustomException;
import com.ewaste.repository.UserRepository;
import com.ewaste.repository.WorkerRepository;
import com.ewaste.security.JwtService;
import com.ewaste.service.AuthService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;
    private final WorkerRepository workerRepo;
    private final UserRepository userRepo;
    private final JwtService jwtService;
    private final ConcurrentHashMap<String, String> aadhaarOtpStore = new ConcurrentHashMap<>();

    public AuthController(AuthService a, WorkerRepository w, UserRepository u, JwtService j) {
        authService=a; workerRepo=w; userRepo=u; jwtService=j;
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> register(@Valid @RequestBody RegisterRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(authService.register(req)));
    }

    @PostMapping("/register-worker")
    public ResponseEntity<ApiResponse<String>> registerWorker(@Valid @RequestBody WorkerRegisterRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(authService.registerWorker(req)));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest req) {
        LoginResponse resp = authService.login(req);
        if ("AADHAAR_REQUIRED".equals(resp.getMessage()))
            return ResponseEntity.status(HttpStatus.ACCEPTED)
                    .body(new ApiResponse<>(false, "AADHAAR_REQUIRED", resp));
        if (resp.getToken() == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ApiResponse.error(resp.getMessage()));
        return ResponseEntity.ok(ApiResponse.ok("Login successful", resp));
    }

    @PostMapping("/worker/aadhaar/send-otp")
    public ResponseEntity<ApiResponse<String>> sendAadhaarOtp(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String aadhaar = body.get("aadhaarNumber");
        if (email == null || aadhaar == null || !aadhaar.matches("\\d{12}"))
            throw new CustomException("Valid 12-digit Aadhaar required");
        Worker w = workerRepo.findByEmail(email).orElseThrow(() -> new CustomException("Worker not found"));
        String otp = String.valueOf(100000 + (int)(Math.random() * 900000));
        aadhaarOtpStore.put(email, otp);
        w.setAadhaarNumber(aadhaar);
        workerRepo.save(w);
        System.out.println("\n>>> AADHAAR OTP for [" + email + "]: " + otp + " <<<\n");
        return ResponseEntity.ok(ApiResponse.ok("OTP generated. Check server console."));
    }

    @PostMapping("/worker/aadhaar/verify-otp")
    public ResponseEntity<ApiResponse<LoginResponse>> verifyAadhaarOtp(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String otp   = body.get("otp");
        String stored = aadhaarOtpStore.get(email);
        if (stored == null || !stored.equals(otp)) throw new CustomException("Invalid or expired OTP");
        Worker w = workerRepo.findByEmail(email).orElseThrow(() -> new CustomException("Worker not found"));
        w.setAadhaarVerified(true);
        workerRepo.save(w);
        aadhaarOtpStore.remove(email);
        User user = userRepo.findByEmail(email).orElseThrow(() -> new CustomException("User not found"));
        String token = jwtService.generateToken(user.getEmail(), user.getRole().name());
        return ResponseEntity.ok(ApiResponse.ok("Aadhaar verified", new LoginResponse(token, "Login granted", user)));
    }
}
