package com.ewaste.controller.request;

import com.ewaste.dto.ApiResponse;
import com.ewaste.dto.request.*;
import com.ewaste.entity.*;
import com.ewaste.enums.RequestStatus;
import com.ewaste.service.request.EwasteService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ewaste")
public class EwasteController {

    private final EwasteService service;
    public EwasteController(EwasteService s) { service=s; }

    // ── Master Data ───────────────────────────────────
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/timeslots") public ResponseEntity<ApiResponse<List<TimeSlot>>> slots() { return ResponseEntity.ok(ApiResponse.ok("ok", service.getAllTimeSlots())); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/items")     public ResponseEntity<ApiResponse<List<EwasteItem>>>  items() { return ResponseEntity.ok(ApiResponse.ok("ok", service.getAllItems())); }

    // ── User ──────────────────────────────────────────
    @PreAuthorize("hasRole('USER')")
    @PostMapping("/user/request")
    public ResponseEntity<ApiResponse<CreateRequestResponse>> createRequest(@Valid @RequestBody CreateRequestDTO dto) {
        return ResponseEntity.ok(ApiResponse.ok("Submitted", service.createRequest(dto)));
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/user/requests")
    public ResponseEntity<ApiResponse<List<EwasteRequest>>> myRequests() {
        return ResponseEntity.ok(ApiResponse.ok("ok", service.getMyRequests()));
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/user/rate")
    public ResponseEntity<ApiResponse<Void>> rate(@Valid @RequestBody RatingDTO dto) {
        service.rateWorker(dto); return ResponseEntity.ok(ApiResponse.ok("Rating submitted"));
    }

    // ── Admin ─────────────────────────────────────────
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/requests")
    public ResponseEntity<ApiResponse<List<EwasteRequest>>> allRequests() {
        return ResponseEntity.ok(ApiResponse.ok("ok", service.getAllRequests()));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/requests/status/{status}")
    public ResponseEntity<ApiResponse<List<EwasteRequest>>> byStatus(@PathVariable String status) {
        return ResponseEntity.ok(ApiResponse.ok("ok", service.getRequestsByStatus(RequestStatus.valueOf(status.toUpperCase()))));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/admin/requests/{id}/approve")
    public ResponseEntity<ApiResponse<Void>> approve(@PathVariable Long id) {
        service.approveRequest(id); return ResponseEntity.ok(ApiResponse.ok("Approved"));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/admin/requests/{id}/reject")
    public ResponseEntity<ApiResponse<Void>> reject(@PathVariable Long id, @Valid @RequestBody RejectRequestDTO body) {
        service.rejectRequest(id, body.getReason()); return ResponseEntity.ok(ApiResponse.ok("Rejected"));
    }

    // ── Worker ────────────────────────────────────────
    @PreAuthorize("hasRole('WORKER')")
    @GetMapping("/worker/requests")
    public ResponseEntity<ApiResponse<List<EwasteRequest>>> myAssigned() {
        return ResponseEntity.ok(ApiResponse.ok("ok", service.getMyAssignedRequests()));
    }

    @PreAuthorize("hasRole('WORKER')")
    @GetMapping("/worker/available-requests")
    public ResponseEntity<ApiResponse<List<EwasteRequest>>> availableRequests() {
        return ResponseEntity.ok(ApiResponse.ok("ok", service.getAvailableRequestsForWorker()));
    }

    @PreAuthorize("hasRole('WORKER')")
    @PostMapping("/worker/requests/{id}/accept")
    public ResponseEntity<ApiResponse<Void>> acceptRequest(@PathVariable Long id) {
        service.acceptRequest(id);
        return ResponseEntity.ok(ApiResponse.ok("Request accepted for pickup"));
    }

    @PreAuthorize("hasRole('WORKER')")
    @PostMapping("/worker/requests/{id}/generate-otp")
    public ResponseEntity<ApiResponse<String>> generateOtp(@PathVariable Long id) {
        String otp = service.generatePickupOtp(id);
        return ResponseEntity.ok(ApiResponse.ok("OTP generated", otp));
    }

    @PreAuthorize("hasRole('WORKER')")
    @PostMapping("/worker/requests/{id}/verify-otp")
    public ResponseEntity<ApiResponse<Void>> verifyOtp(@PathVariable Long id, @RequestBody Map<String,String> body) {
        service.verifyPickupOtp(id, body.get("otp")); return ResponseEntity.ok(ApiResponse.ok("Pickup verified and completed"));
    }
}
