package com.ewaste.controller;

import com.ewaste.dto.ApiResponse;
import com.ewaste.dto.request.PlaceOrderRequest;
import com.ewaste.entity.*;
import com.ewaste.service.ShopService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shop")
public class ShopController {

    private final ShopService shopService;
    public ShopController(ShopService s) { shopService=s; }

    // ── Products (public) ─────────────────────────────
    @GetMapping("/products")
    public ResponseEntity<ApiResponse<List<Product>>> products() {
        return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getAllProducts()));
    }

    @GetMapping("/products/category/{category}")
    public ResponseEntity<ApiResponse<List<Product>>> byCategory(@PathVariable String category) {
        return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getProductsByCategory(category)));
    }

    @GetMapping("/products/{id}")
    public ResponseEntity<ApiResponse<Product>> product(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getProduct(id)));
    }

    // ── Cart (user) ───────────────────────────────────
    @PreAuthorize("hasRole('USER')")
    @GetMapping("/cart")
    public ResponseEntity<ApiResponse<List<CartItem>>> cart() {
        return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getMyCart()));
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/cart/add")
    public ResponseEntity<ApiResponse<CartItem>> addToCart(@RequestBody Map<String,Object> body) {
        Long productId = Long.valueOf(body.get("productId").toString());
        int quantity   = Integer.parseInt(body.get("quantity").toString());
        return ResponseEntity.ok(ApiResponse.ok("Added to cart", shopService.addToCart(productId, quantity)));
    }

    @PreAuthorize("hasRole('USER')")
    @PutMapping("/cart/{id}")
    public ResponseEntity<ApiResponse<Void>> updateCart(@PathVariable Long id, @RequestBody Map<String,Object> body) {
        shopService.updateCartItem(id, Integer.parseInt(body.get("quantity").toString()));
        return ResponseEntity.ok(ApiResponse.ok("Cart updated"));
    }

    @PreAuthorize("hasRole('USER')")
    @DeleteMapping("/cart/{id}")
    public ResponseEntity<ApiResponse<Void>> removeFromCart(@PathVariable Long id) {
        shopService.removeFromCart(id); return ResponseEntity.ok(ApiResponse.ok("Removed"));
    }

    // ── Orders (user) ─────────────────────────────────
    @PreAuthorize("hasRole('USER')")
    @PostMapping("/orders")
    public ResponseEntity<ApiResponse<Order>> placeOrder(@Valid @RequestBody PlaceOrderRequest req) {
        return ResponseEntity.ok(ApiResponse.ok("Order placed", shopService.placeOrder(req)));
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<List<Order>>> myOrders() {
        return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getMyOrders()));
    }
}
