package com.ewaste.controller;

import com.ewaste.dto.*;
import com.ewaste.entity.*;
import com.ewaste.enums.OrderStatus;
//import com.ewaste.enums.WorkerStatus;
import com.ewaste.service.AdminService;
import com.ewaste.service.ShopService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;


@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService adminService;
    private final ShopService shopService;

    public AdminController(AdminService a, ShopService s) { adminService=a; shopService=s; }

    // ── Dashboard Stats ───────────────────────────────
    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<Map<String,Object>>> stats() {
        return ResponseEntity.ok(ApiResponse.ok("Stats", adminService.getDashboardStats()));
    }

    // ── Users ─────────────────────────────────────────
    @GetMapping("/users/pending")  public ResponseEntity<ApiResponse<List<User>>> pending()  { return ResponseEntity.ok(ApiResponse.ok("ok", adminService.getPendingUsers())); }
    @GetMapping("/users/approved") public ResponseEntity<ApiResponse<List<User>>> approved() { return ResponseEntity.ok(ApiResponse.ok("ok", adminService.getApprovedUsers())); }
    @GetMapping("/users/rejected") public ResponseEntity<ApiResponse<List<User>>> rejected() { return ResponseEntity.ok(ApiResponse.ok("ok", adminService.getRejectedUsers())); }
    @GetMapping("/users")          public ResponseEntity<ApiResponse<List<User>>> all()      { return ResponseEntity.ok(ApiResponse.ok("ok", adminService.getAllUsers())); }

    @PutMapping("/users/{id}/approve")
    public ResponseEntity<ApiResponse<User>> approveUser(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("User approved", adminService.approveUser(id)));
    }

    @PutMapping("/users/{id}/reject")
    public ResponseEntity<ApiResponse<User>> rejectUser(@PathVariable Long id, @RequestBody Map<String,String> b) {
        return ResponseEntity.ok(ApiResponse.ok("User rejected", adminService.rejectUser(id, b.get("reason"))));
    }

    // ── Workers ───────────────────────────────────────
    @GetMapping("/workers")           public ResponseEntity<ApiResponse<List<Worker>>> workers()   { return ResponseEntity.ok(ApiResponse.ok("ok", adminService.getAllWorkers())); }
    @GetMapping("/workers/available") public ResponseEntity<ApiResponse<List<Worker>>> available() { return ResponseEntity.ok(ApiResponse.ok("ok", adminService.getAvailableWorkers())); }

    @PostMapping("/workers")
    public ResponseEntity<ApiResponse<Worker>> createWorker(@Valid @RequestBody CreateWorkerAccountRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Worker created", adminService.createWorker(req)));
    }

    @DeleteMapping("/workers/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteWorker(@PathVariable Long id) {
        adminService.deleteWorker(id); return ResponseEntity.ok(ApiResponse.ok("Worker deleted"));
    }

    // ── Products ──────────────────────────────────────
    
    @GetMapping("/products")    public ResponseEntity<ApiResponse<List<Product>>> products()    { return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getAllProductsAdmin())); }
    
    @PostMapping("/products")
    public ResponseEntity<ApiResponse<Product>> addProduct(
            @RequestParam("file") MultipartFile file,
            @RequestParam String name,
            @RequestParam String description,
            @RequestParam double price,
            @RequestParam double originalPrice,
            @RequestParam String category,
            @RequestParam int stock,
            @RequestParam boolean isActive
    ) throws IOException {

        Product product =
                shopService.saveProductWithImage(
                        file,
                        name,
                        description,
                        price,
                        originalPrice,
                        category,
                        stock,
                        isActive);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Product added", product));
    }
    @PutMapping("/products/{id}")
    public ResponseEntity<ApiResponse<Product>> updateProduct(
            @PathVariable Long id,
            @RequestParam(required = false) MultipartFile file,
            @RequestParam String name,
            @RequestParam String description,
            @RequestParam double price,
            @RequestParam double originalPrice,
            @RequestParam String category,
            @RequestParam int stock,
            @RequestParam boolean isActive
    ) throws IOException {

        Product product = shopService.updateProduct(
                id,
                file,
                name,
                description,
                price,
                originalPrice,
                category,
                stock,
                isActive
        );

        return ResponseEntity.ok(
                ApiResponse.ok("Updated", product)
        );
    }
    
    @DeleteMapping("/products/{id}") public ResponseEntity<ApiResponse<Void>> deleteProduct(@PathVariable Long id) { shopService.deleteProduct(id); return ResponseEntity.ok(ApiResponse.ok("Deleted")); }

    // ── Orders ────────────────────────────────────────
    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<List<Order>>> allOrders() {
        return ResponseEntity.ok(ApiResponse.ok("ok", shopService.getAllOrders()));
    }

    @PutMapping("/orders/{id}/status")
    public ResponseEntity<ApiResponse<Order>> updateOrderStatus(@PathVariable Long id, @RequestBody Map<String,String> b) {
        OrderStatus status = OrderStatus.valueOf(b.get("status").toUpperCase());
        return ResponseEntity.ok(ApiResponse.ok("Status updated", shopService.updateOrderStatus(id, status)));
    }
}
