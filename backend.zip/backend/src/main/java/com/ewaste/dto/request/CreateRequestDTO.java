package com.ewaste.dto.request;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.List;
public class CreateRequestDTO {
    @NotBlank private String address;
    @NotBlank private String city;
    private Double latitude;
    private Double longitude;
    @NotNull private LocalDate preferredDate;
    @NotNull private Long timeSlotId;
    @NotEmpty private List<ItemDTO> items;
    public String getAddress(){return address;} public void setAddress(String a){this.address=a;}
    public String getCity(){return city;} public void setCity(String c){this.city=c;}
    public Double getLatitude(){return latitude;} public void setLatitude(Double l){this.latitude=l;}
    public Double getLongitude(){return longitude;} public void setLongitude(Double l){this.longitude=l;}
    public LocalDate getPreferredDate(){return preferredDate;} public void setPreferredDate(LocalDate d){this.preferredDate=d;}
    public Long getTimeSlotId(){return timeSlotId;} public void setTimeSlotId(Long t){this.timeSlotId=t;}
    public List<ItemDTO> getItems(){return items;} public void setItems(List<ItemDTO> i){this.items=i;}
}
