package com.ewaste.dto.request;
import jakarta.validation.constraints.NotNull;
public class AssignWorkerRequest {
    @NotNull private Long workerId;
    public Long getWorkerId(){return workerId;} public void setWorkerId(Long w){this.workerId=w;}
}
