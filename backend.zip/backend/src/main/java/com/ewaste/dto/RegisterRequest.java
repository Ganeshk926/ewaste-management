package com.ewaste.dto;
import jakarta.validation.constraints.*;
public class RegisterRequest {
    @NotBlank private String name;
    @NotBlank @Size(min=3) private String username;
    @Email @NotBlank private String email;
    @NotBlank @Pattern(regexp="^[0-9]{10}$") private String phone;
    @NotBlank @Size(min=6) private String password;
    public String getName(){return name;} public void setName(String n){this.name=n;}
    public String getUsername(){return username;} public void setUsername(String u){this.username=u;}
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getPhone(){return phone;} public void setPhone(String p){this.phone=p;}
    public String getPassword(){return password;} public void setPassword(String p){this.password=p;}
}
