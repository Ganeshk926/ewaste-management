package com.ewaste.dto.request;
public class CreateRequestResponse {
    private Long requestId; private String message;
    public Long getRequestId(){return requestId;} public void setRequestId(Long r){this.requestId=r;}
    public String getMessage(){return message;} public void setMessage(String m){this.message=m;}
}
