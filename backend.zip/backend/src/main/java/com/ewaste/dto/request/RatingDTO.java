package com.ewaste.dto.request;
import jakarta.validation.constraints.*;
public class RatingDTO {
    @NotNull private Long requestId;
    @Min(1) @Max(5) private int rating;
    private String feedback;
    public Long getRequestId(){return requestId;} public void setRequestId(Long r){this.requestId=r;}
    public int getRating(){return rating;} public void setRating(int r){this.rating=r;}
    public String getFeedback(){return feedback;} public void setFeedback(String f){this.feedback=f;}
}
