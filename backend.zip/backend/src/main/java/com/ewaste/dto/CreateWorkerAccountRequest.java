package com.ewaste.dto;
import jakarta.validation.constraints.*;
public class CreateWorkerAccountRequest {
    @NotBlank private String name;
    @NotBlank private String username;
    @Email @NotBlank private String email;
    @NotBlank private String phone;
    @NotBlank(message = "Password is required") private String password;
    @NotBlank(message = "City is required") private String city;
    @NotBlank(message = "Vehicle number is required") private String vehicleNumber;
    @NotBlank(message = "Licence number is required") private String licenceNumber;
    public String getName(){return name;} public void setName(String n){this.name=n;}
    public String getUsername(){return username;} public void setUsername(String u){this.username=u;}
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getPhone()    { return phone; }    public void setPhone(String p)    { this.phone = p; }
    public String getPassword() { return password; } public void setPassword(String p) { this.password = p; }
    public String getCity()     { return city; }     public void setCity(String c)     { this.city = c; }
    public String getVehicleNumber() { return vehicleNumber; } public void setVehicleNumber(String v) { this.vehicleNumber = v; }
    public String getLicenceNumber() { return licenceNumber; } public void setLicenceNumber(String l) { this.licenceNumber = l; }
}
