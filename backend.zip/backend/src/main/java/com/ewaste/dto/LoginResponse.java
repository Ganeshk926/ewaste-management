package com.ewaste.dto;
import com.ewaste.entity.User;
public class LoginResponse {
    private String token; private String message; private User user;
    public LoginResponse(){}
    public LoginResponse(String t,String m,User u){this.token=t;this.message=m;this.user=u;}
    public String getToken(){return token;} public void setToken(String t){this.token=t;}
    public String getMessage(){return message;} public void setMessage(String m){this.message=m;}
    public User getUser(){return user;} public void setUser(User u){this.user=u;}
}
