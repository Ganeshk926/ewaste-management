package com.ewaste.dto.pswd;
public class ResetPasswordRequest {
    private String email; private String newPassword;
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getNewPassword(){return newPassword;} public void setNewPassword(String n){this.newPassword=n;}
}
