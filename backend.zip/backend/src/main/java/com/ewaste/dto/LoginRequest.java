package com.ewaste.dto;
public class LoginRequest {
    private String email; private String password;
    public LoginRequest(){}
    public LoginRequest(String e,String p){this.email=e;this.password=p;}
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getPassword(){return password;} public void setPassword(String p){this.password=p;}
}
