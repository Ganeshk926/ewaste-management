package com.ewaste.dto.request;
import jakarta.validation.constraints.NotBlank;
public class PlaceOrderRequest {
    @NotBlank private String paymentMethod;
    @NotBlank private String deliveryAddress;
    private boolean usePoints = false;
    public String getPaymentMethod(){return paymentMethod;} public void setPaymentMethod(String p){this.paymentMethod=p;}
    public String getDeliveryAddress(){return deliveryAddress;} public void setDeliveryAddress(String d){this.deliveryAddress=d;}
    public boolean isUsePoints(){return usePoints;} public void setUsePoints(boolean u){this.usePoints=u;}
}
