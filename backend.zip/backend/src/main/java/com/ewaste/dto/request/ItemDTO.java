package com.ewaste.dto.request;
public class ItemDTO {
    private Long itemId; private int quantity;
    public Long getItemId(){return itemId;} public void setItemId(Long i){this.itemId=i;}
    public int getQuantity(){return quantity;} public void setQuantity(int q){this.quantity=q;}
}
