package com.ewaste.dto.request;
import jakarta.validation.constraints.*;
public class RejectRequestDTO {
    @NotBlank @Size(min=5,max=500) private String reason;
    public String getReason(){return reason;} public void setReason(String r){this.reason=r;}
}
