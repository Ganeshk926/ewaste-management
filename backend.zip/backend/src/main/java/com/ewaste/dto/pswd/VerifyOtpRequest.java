package com.ewaste.dto.pswd;
public class VerifyOtpRequest {
    private String email; private String otp;
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getOtp(){return otp;} public void setOtp(String o){this.otp=o;}
}
