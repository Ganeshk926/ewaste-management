package com.ewaste.dto.pswd;
import jakarta.validation.constraints.Email;
public class ForgotPasswordRequest {
    @Email private String email;
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
}
