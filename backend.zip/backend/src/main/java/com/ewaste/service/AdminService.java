package com.ewaste.service;

import com.ewaste.dto.CreateWorkerAccountRequest;
import com.ewaste.entity.User;
import com.ewaste.entity.Worker;
import com.ewaste.enums.Role;
import com.ewaste.enums.Status;
import com.ewaste.enums.WorkerStatus;
import com.ewaste.exception.CustomException;
import com.ewaste.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
	
import java.util.*;

@Service
public class AdminService {
    private static final Logger log = LoggerFactory.getLogger(AdminService.class);

    private final UserRepository userRepo;
    private final WorkerRepository workerRepo;
    private final BCryptPasswordEncoder encoder;
    private final EwasteRequestRepository requestRepo;
    private final OrderRepository orderRepo;
    private final RatingRepository ratingRepo;

    public AdminService(UserRepository u, WorkerRepository w, BCryptPasswordEncoder e,
                        EwasteRequestRepository r, OrderRepository o, RatingRepository ra) {
        userRepo=u; workerRepo=w; encoder=e; requestRepo=r; orderRepo=o; ratingRepo=ra;
    }

    public List<User> getPendingUsers()  { return userRepo.findByStatus(Status.PENDING); }
    public List<User> getApprovedUsers() { return userRepo.findByStatus(Status.APPROVED); }
    public List<User> getRejectedUsers() { return userRepo.findByStatus(Status.REJECTED); }
    public List<User> getAllUsers()       { return userRepo.findAll(); }

    @Transactional
    public User approveUser(Long id) {
        User u = userRepo.findById(id).orElseThrow(() -> new CustomException("User not found"));
        if (u.getStatus() != Status.PENDING) throw new CustomException("User not in PENDING state");
        u.setStatus(Status.APPROVED);
        return userRepo.save(u);
    }

    @Transactional
    public User rejectUser(Long id, String reason) {
        User u = userRepo.findById(id).orElseThrow(() -> new CustomException("User not found"));
        if (u.getStatus() != Status.PENDING) throw new CustomException("User not in PENDING state");
        u.setStatus(Status.REJECTED);
        return userRepo.save(u);
    }

    public List<Worker> getAllWorkers()       { return workerRepo.findAll(); }
    public List<Worker> getAvailableWorkers() { return workerRepo.findByStatus(WorkerStatus.AVAILABLE); }

    @Transactional
    public Worker createWorker(CreateWorkerAccountRequest req) {
        if (userRepo.existsByEmail(req.getEmail())) throw new CustomException("Email already registered");
        if (userRepo.existsByUsername(req.getUsername())) throw new CustomException("Username taken");

        User user = new User();
        user.setName(req.getName()); user.setUsername(req.getUsername());
        user.setEmail(req.getEmail()); user.setPhone(req.getPhone());
        user.setPassword(encoder.encode(req.getPassword()));
        user.setRole(Role.WORKER); user.setStatus(Status.APPROVED);
        userRepo.save(user);

        Worker worker = new Worker();
        worker.setName(req.getName()); worker.setEmail(req.getEmail());
        worker.setPhone(req.getPhone()); worker.setStatus(WorkerStatus.AVAILABLE);
        worker.setCity(req.getCity());
        worker.setVehicleNumber(req.getVehicleNumber());
        worker.setLicenceNumber(req.getLicenceNumber());
        worker.setAadhaarVerified(false); // require Aadhaar verification on first login
        return workerRepo.save(worker);
    }

    @Transactional
    public void deleteWorker(Long id) {
        Worker w = workerRepo.findById(id).orElseThrow(() -> new CustomException("Worker not found"));
        if (w.getStatus() == WorkerStatus.ASSIGNED) throw new CustomException("Cannot delete assigned worker");
        userRepo.findByEmail(w.getEmail()).ifPresent(userRepo::delete);
        workerRepo.deleteById(id);
    }

    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalUsers",      userRepo.findByStatus(Status.APPROVED).size());
        stats.put("pendingUsers",    userRepo.findByStatus(Status.PENDING).size());
        stats.put("totalWorkers",    workerRepo.count());
        stats.put("availableWorkers",workerRepo.findByStatus(WorkerStatus.AVAILABLE).size());
        stats.put("pendingRequests", requestRepo.countByStatus(com.ewaste.enums.RequestStatus.PENDING));
        stats.put("approvedRequests",requestRepo.countByStatus(com.ewaste.enums.RequestStatus.APPROVED));
        stats.put("completedRequests",requestRepo.countByStatus(com.ewaste.enums.RequestStatus.COMPLETED));
        stats.put("totalOrders",     orderRepo.count());
        stats.put("pendingOrders",   orderRepo.countByOrderStatus(com.ewaste.enums.OrderStatus.ORDERED));
        return stats;
    }
}
