package com.ewaste.service;

import com.ewaste.dto.*;
import com.ewaste.entity.User;
import com.ewaste.entity.Worker;
import com.ewaste.enums.Role;
import com.ewaste.enums.Status;
import com.ewaste.enums.WorkerStatus;
import com.ewaste.exception.CustomException;
import com.ewaste.repository.UserRepository;
import com.ewaste.repository.WorkerRepository;
import com.ewaste.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository userRepo;
    private final WorkerRepository workerRepo;
    private final BCryptPasswordEncoder encoder;
    private final JwtService jwtService;

    public AuthService(UserRepository u, WorkerRepository w, BCryptPasswordEncoder e, JwtService j) {
        this.userRepo=u; this.workerRepo=w; this.encoder=e; this.jwtService=j;
    }

    public String register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail())) throw new CustomException("Email already registered");
        if (userRepo.existsByUsername(req.getUsername())) throw new CustomException("Username already taken");
        User user = new User();
        user.setName(req.getName()); user.setUsername(req.getUsername());
        user.setPhone(req.getPhone()); user.setEmail(req.getEmail());
        user.setPassword(encoder.encode(req.getPassword()));
        user.setRole(Role.USER); user.setStatus(Status.PENDING);
        userRepo.save(user);
        log.info("User registered: {}", req.getEmail());
        return "Registration successful. Awaiting admin approval.";
    }

    @Transactional
    public String registerWorker(WorkerRegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail())) throw new CustomException("Email already registered");
        if (userRepo.existsByUsername(req.getUsername())) throw new CustomException("Username taken");
        if (workerRepo.existsByEmail(req.getEmail())) throw new CustomException("Worker profile exists");

        User user = new User();
        user.setName(req.getName()); user.setUsername(req.getUsername());
        user.setPhone(req.getPhone()); user.setEmail(req.getEmail());
        user.setPassword(encoder.encode(req.getPassword()));
        user.setRole(Role.WORKER); user.setStatus(Status.PENDING);
        userRepo.save(user);

        Worker worker = new Worker();
        worker.setName(req.getName()); worker.setEmail(req.getEmail());
        worker.setPhone(req.getPhone()); worker.setVehicleNumber(req.getVehicleNumber());
        worker.setLicenceNumber(req.getLicenceNumber()); worker.setCity(req.getCity());
        worker.setStatus(WorkerStatus.AVAILABLE); worker.setAadhaarVerified(false);
        workerRepo.save(worker);
        log.info("Worker registered: {}", req.getEmail());
        return "Worker registration submitted. Awaiting admin approval.";
    }

    public LoginResponse login(LoginRequest req) {
        User user = userRepo.findByEmail(req.getEmail()).orElse(null);
        if (user == null) return new LoginResponse(null, "No account found with this email", null);
        if (!encoder.matches(req.getPassword(), user.getPassword())) return new LoginResponse(null, "Incorrect password", null);
        if (user.getStatus() == Status.PENDING)  return new LoginResponse(null, "Account pending admin approval", null);
        if (user.getStatus() == Status.REJECTED) return new LoginResponse(null, "Account registration was rejected", null);

        if (user.getRole() == Role.WORKER) {
            Worker w = workerRepo.findByEmail(user.getEmail()).orElse(null);
            if (w != null && !w.isAadhaarVerified())
                return new LoginResponse(null, "AADHAAR_REQUIRED", user);
        }

        String token = jwtService.generateToken(user.getEmail(), user.getRole().name());
        log.info("Login: {} ({})", user.getEmail(), user.getRole());
        return new LoginResponse(token, "Login successful", user);
    }
}
