package com.ewaste.service.request;

import com.ewaste.dto.request.*;
import com.ewaste.entity.*;
import com.ewaste.enums.RequestStatus;
import com.ewaste.enums.WorkerStatus;
import com.ewaste.exception.CustomException;
import com.ewaste.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class EwasteService {
    private static final Logger log = LoggerFactory.getLogger(EwasteService.class);

    private final EwasteRequestRepository requestRepo;
    private final EwasteRequestItemRepository itemRepo;
    private final TimeSlotRepository slotRepo;
    private final EwasteItemRepository itemMasterRepo;
    private final UserRepository userRepo;
    private final WorkerRepository workerRepo;
    private final RatingRepository ratingRepo;

    public EwasteService(EwasteRequestRepository rr, EwasteRequestItemRepository ir,
                         TimeSlotRepository sr, EwasteItemRepository imr,
                         UserRepository ur, WorkerRepository wr, RatingRepository ra) {
        requestRepo=rr; itemRepo=ir; slotRepo=sr; itemMasterRepo=imr;
        userRepo=ur; workerRepo=wr; ratingRepo=ra;
    }

    // ── Enrich item names ─────────────────────────────
    private void enrichItems(List<EwasteRequest> reqs) {
        Set<Long> ids = new HashSet<>();
        for (EwasteRequest r : reqs) { List<EwasteRequestItem> it = itemRepo.findByRequestId(r.getId()); r.setItems(it); it.forEach(i->ids.add(i.getItemId())); }
        Map<Long,String> nameMap = new HashMap<>();
        if (!ids.isEmpty()) itemMasterRepo.findAllById(ids).forEach(e->nameMap.put(e.getId(),e.getName()));
        reqs.forEach(r->r.getItems().forEach(i->i.setItemName(nameMap.getOrDefault(i.getItemId(),"Item #"+i.getItemId()))));
    }

    private void enrichSingle(EwasteRequest r) { enrichItems(List.of(r)); }

    // ── USER ──────────────────────────────────────────
    @Transactional
    public CreateRequestResponse createRequest(CreateRequestDTO dto) {
        User user = userRepo.findByEmail(currentEmail()).orElseThrow(()->new CustomException("User not found"));
        slotRepo.findById(dto.getTimeSlotId()).orElseThrow(()->new CustomException("Invalid time slot"));
        for (ItemDTO i : dto.getItems()) itemMasterRepo.findById(i.getItemId()).orElseThrow(()->new CustomException("Invalid item: "+i.getItemId()));

        EwasteRequest req = new EwasteRequest();
        req.setUserId(user.getId()); req.setAddress(dto.getAddress());
        req.setCity(dto.getCity());
        req.setLatitude(dto.getLatitude()); req.setLongitude(dto.getLongitude());
        req.setPreferredDate(dto.getPreferredDate()); req.setTimeSlotId(dto.getTimeSlotId());
        req.setStatus(RequestStatus.PENDING);
        req = requestRepo.save(req);

        List<EwasteRequestItem> items = new ArrayList<>();
        for (ItemDTO i : dto.getItems()) { EwasteRequestItem ri=new EwasteRequestItem(); ri.setRequestId(req.getId()); ri.setItemId(i.getItemId()); ri.setQuantity(i.getQuantity()); items.add(ri); }
        itemRepo.saveAll(items);

        // 10 reward points per item submitted
        int points = dto.getItems().stream().mapToInt(ItemDTO::getQuantity).sum() * 10;
        user.setRewardPoints(user.getRewardPoints() + points);
        userRepo.save(user);

        log.info("Request #{} created by {}", req.getId(), currentEmail());
        CreateRequestResponse resp = new CreateRequestResponse();
        resp.setRequestId(req.getId());
        resp.setMessage("Request submitted! You earned " + points + " reward points.");
        return resp;
    }

    public List<EwasteRequest> getMyRequests() {
        User user = userRepo.findByEmail(currentEmail()).orElseThrow(()->new CustomException("User not found"));
        List<EwasteRequest> reqs = requestRepo.findByUserId(user.getId());
        enrichItems(reqs);
        return reqs;
    }

    // ── ADMIN ─────────────────────────────────────────
    public List<EwasteRequest> getAllRequests() { List<EwasteRequest> r=requestRepo.findAll(); enrichItems(r); return r; }

    public List<EwasteRequest> getRequestsByStatus(RequestStatus s) { List<EwasteRequest> r=requestRepo.findByStatus(s); enrichItems(r); return r; }

    @Transactional
    public void approveRequest(Long reqId) {
        EwasteRequest req = requestRepo.findById(reqId).orElseThrow(()->new CustomException("Request not found"));
        if (req.getStatus()!=RequestStatus.PENDING) throw new CustomException("Only PENDING can be approved");
        req.setStatus(RequestStatus.APPROVED); req.setApprovedAt(LocalDateTime.now());
        requestRepo.save(req);
    }

    @Transactional
    public void rejectRequest(Long reqId, String reason) {
        EwasteRequest req = requestRepo.findById(reqId).orElseThrow(()->new CustomException("Request not found"));
        if (req.getStatus()!=RequestStatus.PENDING) throw new CustomException("Only PENDING can be rejected");
        req.setStatus(RequestStatus.REJECTED); req.setAdminRemarks(reason);
        requestRepo.save(req);
    }

    // ── WORKER: Generate Pickup OTP ───────────────────
    @Transactional
    public String generatePickupOtp(Long reqId) {
        String email = currentEmail();
        EwasteRequest req = requestRepo.findById(reqId).orElseThrow(()->new CustomException("Request not found"));
        if (req.getAssignedWorker()==null||!req.getAssignedWorker().getEmail().equals(email))
            throw new CustomException("Not assigned to you");
        if (req.getStatus()!=RequestStatus.APPROVED) throw new CustomException("Request not approved");

        String otp = String.valueOf(100000 + new Random().nextInt(900000));
        req.setPickupOtp(otp); req.setOtpGeneratedAt(LocalDateTime.now());
        requestRepo.save(req);

        // OTP shown in user dashboard — also print to console for dev
        System.out.println(">>> PICKUP OTP for Request #" + reqId + ": " + otp + " <<<");
        return otp; // returned to worker dashboard to display
    }

    // ── WORKER: Verify OTP and complete ──────────────
    @Transactional
    public void verifyPickupOtp(Long reqId, String otp) {
        String email = currentEmail();
        EwasteRequest req = requestRepo.findById(reqId).orElseThrow(()->new CustomException("Request not found"));
        if (req.getAssignedWorker()==null||!req.getAssignedWorker().getEmail().equals(email))
            throw new CustomException("Not assigned to you");
        if (req.getPickupOtp()==null) throw new CustomException("OTP not generated yet");
        if (!req.getPickupOtp().equals(otp)) throw new CustomException("Invalid OTP");

        // OTP valid for 10 minutes
        if (req.getOtpGeneratedAt().isBefore(LocalDateTime.now().minusMinutes(10)))
            throw new CustomException("OTP expired. Please generate a new one.");

        req.setPickupVerified(true); req.setStatus(RequestStatus.COMPLETED);
        Worker w = req.getAssignedWorker();
        w.setStatus(WorkerStatus.AVAILABLE); w.setTotalPickups(w.getTotalPickups()+1);
        workerRepo.save(w); requestRepo.save(req);
        log.info("Request #{} completed by {}", reqId, email);
    }

    public List<EwasteRequest> getMyAssignedRequests() {
        Worker w = workerRepo.findByEmail(currentEmail()).orElseThrow(()->new CustomException("Worker not found"));
        List<EwasteRequest> reqs = requestRepo.findByAssignedWorkerId(w.getId());
        enrichItems(reqs);
        return reqs;
    }

    public List<EwasteRequest> getAvailableRequestsForWorker() {
        Worker w = workerRepo.findByEmail(currentEmail()).orElseThrow(()->new CustomException("Worker not found"));
        List<EwasteRequest> allApproved = requestRepo.findByStatus(RequestStatus.APPROVED);
        List<EwasteRequest> available = new ArrayList<>();
        for (EwasteRequest req : allApproved) {
            if (req.getAssignedWorker() == null && w.getCity().equalsIgnoreCase(req.getCity())) {
                available.add(req);
            }
        }
        enrichItems(available);
        return available;
    }

    @Transactional
    public void acceptRequest(Long reqId) {
        Worker w = workerRepo.findByEmail(currentEmail()).orElseThrow(()->new CustomException("Worker not found"));
        if (w.getStatus() != WorkerStatus.AVAILABLE) throw new CustomException("You are not available to accept requests");
        
        EwasteRequest req = requestRepo.findById(reqId).orElseThrow(()->new CustomException("Request not found"));
        if (req.getStatus() != RequestStatus.APPROVED) throw new CustomException("Request is not available for pickup");
        if (req.getAssignedWorker() != null) throw new CustomException("Request already accepted by another worker");
        if (!w.getCity().equalsIgnoreCase(req.getCity())) throw new CustomException("Request is not in your city");

        req.setAssignedWorker(w);
        w.setStatus(WorkerStatus.ASSIGNED);
        
        workerRepo.save(w);
        requestRepo.save(req);
    }

    // ── RATING ────────────────────────────────────────
    @Transactional
    public void rateWorker(RatingDTO dto) {
        User user = userRepo.findByEmail(currentEmail()).orElseThrow(()->new CustomException("User not found"));
        EwasteRequest req = requestRepo.findById(dto.getRequestId()).orElseThrow(()->new CustomException("Request not found"));
        if (!req.getUserId().equals(user.getId())) throw new CustomException("Not your request");
        if (req.getStatus()!=RequestStatus.COMPLETED) throw new CustomException("Request not completed yet");
        if (req.isRated()) throw new CustomException("Already rated");
        if (req.getAssignedWorker()==null) throw new CustomException("No worker assigned");

        Rating rating = new Rating();
        rating.setRequestId(req.getId()); rating.setWorkerId(req.getAssignedWorker().getId());
        rating.setUserId(user.getId()); rating.setRating(dto.getRating()); rating.setFeedback(dto.getFeedback());
        ratingRepo.save(rating);

        // Update worker average
        Double avg = ratingRepo.avgRatingByWorkerId(req.getAssignedWorker().getId());
        req.getAssignedWorker().setAverageRating(avg!=null?avg:dto.getRating());
        workerRepo.save(req.getAssignedWorker());

        req.setRated(true); requestRepo.save(req);
    }

    // ── MASTER DATA ───────────────────────────────────
    public List<TimeSlot> getAllTimeSlots() { return slotRepo.findAll(); }
    public List<EwasteItem> getAllItems()   { return itemMasterRepo.findAll(); }

    private String currentEmail() { return SecurityContextHolder.getContext().getAuthentication().getName(); }
}
