package com.ewaste.service;

import com.ewaste.dto.request.PlaceOrderRequest;
import com.ewaste.entity.*;
import com.ewaste.enums.OrderStatus;
import com.ewaste.enums.PaymentStatus;
import com.ewaste.exception.CustomException;
import com.ewaste.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@Service
public class ShopService {
    private static final Logger log = LoggerFactory.getLogger(ShopService.class);

    private final ProductRepository productRepo;
    private final CartItemRepository cartRepo;
    private final OrderRepository orderRepo;
    private final UserRepository userRepo;

    // 1 reward point = ₹1 discount
    private static final int POINTS_PER_RUPEE = 1;
    private static final int MAX_POINTS_DISCOUNT_PERCENT = 20; // max 20% off via points

    public ShopService(ProductRepository p, CartItemRepository c, OrderRepository o, UserRepository u) {
        productRepo=p; cartRepo=c; orderRepo=o; userRepo=u;
    }

    // ── PRODUCTS ──────────────────────────────────────
    public List<Product> getAllProducts()                          { return productRepo.findByIsActiveTrue(); }
    public List<Product> getProductsByCategory(String category)   { return productRepo.findByCategoryAndIsActiveTrue(category); }
    public Product       getProduct(Long id)                      { return productRepo.findById(id).orElseThrow(()->new CustomException("Product not found")); }

    // Admin
    public Product saveProductWithImage(
            MultipartFile file,
            String name,
            String description,
            double price,
            double originalPrice,
            String category,
            int stock,
            boolean isActive
    ) throws IOException {

        String uploadDir = "uploads/";

        String fileName =
                System.currentTimeMillis()
                + "_"
                + file.getOriginalFilename();

        Path path =
                Paths.get(uploadDir + fileName);

        Files.createDirectories(path.getParent());

        Files.write(path, file.getBytes());

        Product p = new Product();

        p.setName(name);
        p.setDescription(description);
        p.setPrice(price);
        p.setOriginalPrice(originalPrice);
        p.setCategory(category);
        p.setStock(stock);
        p.setActive(isActive);

        p.setImageUrl(fileName);

        return productRepo.save(p);
    }
    public Product updateProduct(
            Long id,
            MultipartFile file,
            String name,
            String description,
            double price,
            double originalPrice,
            String category,
            int stock,
            boolean isActive
    ) throws IOException {

        Product product = productRepo.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Product not found"));

        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setOriginalPrice(originalPrice);
        product.setCategory(category);
        product.setStock(stock);
        product.setActive(isActive);

        // only if new image uploaded
        if (file != null && !file.isEmpty()) {

            String fileName =
                    System.currentTimeMillis()
                    + "_"
                    + file.getOriginalFilename();

            Path path =
                    Paths.get("uploads/" + fileName);

            Files.createDirectories(path.getParent());

            Files.write(path, file.getBytes());

            product.setImageUrl(fileName);
        }

        return productRepo.save(product);
    }
    public void    deleteProduct(Long id)  { productRepo.deleteById(id); }
    public List<Product> getAllProductsAdmin() { return productRepo.findAll(); }

    // ── CART ──────────────────────────────────────────
    public List<CartItem> getMyCart() {
        User user = currentUser();
        List<CartItem> items = cartRepo.findByUserId(user.getId());
        items.forEach(ci -> {
            productRepo.findById(ci.getProductId()).ifPresent(p -> {
                ci.setProductName(p.getName());
                ci.setProductPrice(p.getPrice());
                ci.setProductImageUrl(p.getImageUrl());
            });
        });
        return items;
    }

    @Transactional
    public CartItem addToCart(Long productId, int quantity) {
        User user = currentUser();
        Product p = productRepo.findById(productId).orElseThrow(()->new CustomException("Product not found"));
        if (!p.isActive()) throw new CustomException("Product not available");
        if (p.getStock() < quantity) throw new CustomException("Insufficient stock");

        CartItem existing = cartRepo.findByUserIdAndProductId(user.getId(), productId).orElse(null);
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + quantity);
            return cartRepo.save(existing);
        }
        CartItem ci = new CartItem();
        ci.setUserId(user.getId()); ci.setProductId(productId); ci.setQuantity(quantity);
        return cartRepo.save(ci);
    }

    @Transactional
    public void updateCartItem(Long cartItemId, int quantity) {
        CartItem ci = cartRepo.findById(cartItemId).orElseThrow(()->new CustomException("Cart item not found"));
        if (quantity <= 0) { cartRepo.delete(ci); return; }
        ci.setQuantity(quantity);
        cartRepo.save(ci);
    }

    @Transactional
    public void removeFromCart(Long cartItemId) {
        cartRepo.deleteById(cartItemId);
    }

    @Transactional
    public void clearCart() {
        cartRepo.deleteByUserId(currentUser().getId());
    }

    // ── ORDER ─────────────────────────────────────────
    @Transactional
    public Order placeOrder(PlaceOrderRequest req) {
        User user = currentUser();
        List<CartItem> cartItems = cartRepo.findByUserId(user.getId());
        if (cartItems.isEmpty()) throw new CustomException("Cart is empty");

        // Calculate total
        double total = 0;
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem ci : cartItems) {
            Product p = productRepo.findById(ci.getProductId())
                    .orElseThrow(()->new CustomException("Product not found: "+ci.getProductId()));
            if (p.getStock() < ci.getQuantity()) throw new CustomException("Insufficient stock: "+p.getName());
            total += p.getPrice() * ci.getQuantity();

            OrderItem oi = new OrderItem();
            oi.setProductId(p.getId()); oi.setProductName(p.getName());
            oi.setPrice(p.getPrice()); oi.setQuantity(ci.getQuantity());
            orderItems.add(oi);

            // Reduce stock
            p.setStock(p.getStock() - ci.getQuantity());
            productRepo.save(p);
        }

        // Apply reward points discount
        double discount = 0;
        int pointsUsed = 0;
        if (req.isUsePoints() && user.getRewardPoints() > 0) {
            double maxDiscount = total * MAX_POINTS_DISCOUNT_PERCENT / 100.0;
            discount = Math.min(user.getRewardPoints() / (double)POINTS_PER_RUPEE, maxDiscount);
            pointsUsed = (int)(discount * POINTS_PER_RUPEE);
            user.setRewardPoints(user.getRewardPoints() - pointsUsed);
            userRepo.save(user);
        }

        Order order = new Order();
        order.setUserId(user.getId()); order.setTotalAmount(total - discount);
        order.setDiscountApplied(discount); order.setPointsUsed(pointsUsed);
        order.setPaymentMethod(req.getPaymentMethod());
        order.setPaymentStatus(PaymentStatus.SUCCESS); // simulated
        order.setOrderStatus(OrderStatus.ORDERED);
        order.setDeliveryAddress(req.getDeliveryAddress());
        order = orderRepo.save(order);

        for (OrderItem oi : orderItems) { oi.setOrder(order); }
        order.setItems(orderItems);
        order = orderRepo.save(order);

        cartRepo.deleteByUserId(user.getId());
        log.info("Order #{} placed by {}", order.getId(), currentEmail());
        return order;
    }

    public List<Order> getMyOrders() {
        return orderRepo.findByUserIdOrderByCreatedAtDesc(currentUser().getId());
    }

    // Admin
    public List<Order> getAllOrders() { return orderRepo.findAll(); }

    @Transactional
    public Order updateOrderStatus(Long orderId, OrderStatus status) {
        Order order = orderRepo.findById(orderId).orElseThrow(()->new CustomException("Order not found"));
        order.setOrderStatus(status);
        return orderRepo.save(order);
    }

    private User currentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByEmail(email).orElseThrow(()->new CustomException("User not found"));
    }

    private String currentEmail() {
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }
}
