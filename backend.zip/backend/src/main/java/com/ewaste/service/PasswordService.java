package com.ewaste.service;

import com.ewaste.entity.User;
import com.ewaste.exception.CustomException;
import com.ewaste.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class PasswordService {

    private final UserRepository userRepo;
    private final BCryptPasswordEncoder encoder;

    public PasswordService(UserRepository u, BCryptPasswordEncoder e) { userRepo=u; encoder=e; }

    @Transactional
    public String generateOtp(String email) {
        User user = userRepo.findByEmail(email).orElseThrow(() -> new CustomException("No account with this email"));
        String otp = String.valueOf(100000 + new Random().nextInt(900000));
        user.setResetOtp(otp);
        user.setOtpExpiry(LocalDateTime.now().plusMinutes(10));
        userRepo.save(user);
        System.out.println(">>> PASSWORD RESET OTP for [" + email + "]: " + otp + " <<<");
        return "OTP sent. Check server console for development testing.";
    }

    @Transactional
    public String verifyOtp(String email, String otp) {
        User user = userRepo.findByEmail(email).orElseThrow(() -> new CustomException("No account with this email"));
        if (user.getResetOtp() == null || !user.getResetOtp().equals(otp))
            throw new CustomException("Invalid OTP");
        if (user.getOtpExpiry() == null || user.getOtpExpiry().isBefore(LocalDateTime.now()))
            throw new CustomException("OTP expired");
        return "OTP verified. You may now reset your password.";
    }

    @Transactional
    public String resetPassword(String email, String newPassword) {
        User user = userRepo.findByEmail(email).orElseThrow(() -> new CustomException("No account with this email"));
        user.setPassword(encoder.encode(newPassword));
        user.setResetOtp(null);
        user.setOtpExpiry(null);
        userRepo.save(user);
        return "Password reset successfully. You can now login.";
    }
}
