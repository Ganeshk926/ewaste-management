package com.ewaste.entity;

import com.ewaste.enums.Role;
import com.ewaste.enums.Status;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(unique = true) private String username;
    private String phone;
    @Column(unique = true) private String email;
    @JsonIgnore private String password;
    @Enumerated(EnumType.STRING) private Role role;
    @Enumerated(EnumType.STRING) private Status status;
    @JsonIgnore private String resetOtp;
    @JsonIgnore private LocalDateTime otpExpiry;
    private int rewardPoints = 0;
    private LocalDateTime createdAt;
    @PrePersist protected void onCreate() { this.createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getUsername() { return username; }
    public void setUsername(String u) { this.username = u; }
    public String getPhone() { return phone; }
    public void setPhone(String p) { this.phone = p; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public String getPassword() { return password; }
    public void setPassword(String p) { this.password = p; }
    public Role getRole() { return role; }
    public void setRole(Role r) { this.role = r; }
    public Status getStatus() { return status; }
    public void setStatus(Status s) { this.status = s; }
    public String getResetOtp() { return resetOtp; }
    public void setResetOtp(String o) { this.resetOtp = o; }
    public LocalDateTime getOtpExpiry() { return otpExpiry; }
    public void setOtpExpiry(LocalDateTime o) { this.otpExpiry = o; }
    public int getRewardPoints() { return rewardPoints; }
    public void setRewardPoints(int r) { this.rewardPoints = r; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime c) { this.createdAt = c; }
}
