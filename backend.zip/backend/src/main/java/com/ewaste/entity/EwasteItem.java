package com.ewaste.entity;
import jakarta.persistence.*;
@Entity @Table(name = "ewaste_item_master")
public class EwasteItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String name;
    public Long getId(){return id;} public void setId(Long i){this.id=i;}
    public String getName(){return name;} public void setName(String n){this.name=n;}
}
