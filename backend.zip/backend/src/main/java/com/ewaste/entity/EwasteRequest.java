package com.ewaste.entity;

import com.ewaste.enums.RequestStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "ewaste_request")
public class EwasteRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    @Column(columnDefinition = "TEXT")
    private String address;
    private String city;
    private Double latitude;
    private Double longitude;
    private LocalDate preferredDate;
    private Long timeSlotId;
    @Enumerated(EnumType.STRING)
    private RequestStatus status = RequestStatus.PENDING;
    private String adminRemarks;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "assigned_worker_id")
    private Worker assignedWorker;

    // Pickup OTP verification
    @JsonIgnore private String pickupOtp;
    @JsonIgnore private LocalDateTime otpGeneratedAt;
    private boolean pickupVerified = false;

    private boolean rated = false;
    private LocalDateTime approvedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Transient private List<EwasteRequestItem> items;

    @PrePersist protected void onCreate() { this.createdAt = LocalDateTime.now(); this.updatedAt = LocalDateTime.now(); }
    @PreUpdate  protected void onUpdate() { this.updatedAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long u) { this.userId = u; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public Double getLatitude() { return latitude; }
    public void setLatitude(Double l) { this.latitude = l; }
    public Double getLongitude() { return longitude; }
    public void setLongitude(Double l) { this.longitude = l; }
    public LocalDate getPreferredDate() { return preferredDate; }
    public void setPreferredDate(LocalDate d) { this.preferredDate = d; }
    public Long getTimeSlotId() { return timeSlotId; }
    public void setTimeSlotId(Long t) { this.timeSlotId = t; }
    public RequestStatus getStatus() { return status; }
    public void setStatus(RequestStatus s) { this.status = s; }
    public String getAdminRemarks() { return adminRemarks; }
    public void setAdminRemarks(String r) { this.adminRemarks = r; }
    public Worker getAssignedWorker() { return assignedWorker; }
    public void setAssignedWorker(Worker w) { this.assignedWorker = w; }
    public String getPickupOtp() { return pickupOtp; }
    public void setPickupOtp(String o) { this.pickupOtp = o; }
    public LocalDateTime getOtpGeneratedAt() { return otpGeneratedAt; }
    public void setOtpGeneratedAt(LocalDateTime o) { this.otpGeneratedAt = o; }
    public boolean isPickupVerified() { return pickupVerified; }
    public void setPickupVerified(boolean v) { this.pickupVerified = v; }
    public boolean isRated() { return rated; }
    public void setRated(boolean r) { this.rated = r; }
    public LocalDateTime getApprovedAt() { return approvedAt; }
    public void setApprovedAt(LocalDateTime a) { this.approvedAt = a; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime c) { this.createdAt = c; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime u) { this.updatedAt = u; }
    public List<EwasteRequestItem> getItems() { return items; }
    public void setItems(List<EwasteRequestItem> i) { this.items = i; }
}
