package com.ewaste.entity;

import com.ewaste.enums.WorkerStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "workers")
public class Worker {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(unique = true) private String email;
    private String phone;
    private String vehicleNumber;
    private String licenceNumber;
    @JsonIgnore private String aadhaarNumber;
    private boolean aadhaarVerified = false;
    @Enumerated(EnumType.STRING)
    private WorkerStatus status = WorkerStatus.AVAILABLE;
    private String city;
    private double averageRating = 0.0;
    private int totalPickups = 0;
    private LocalDateTime createdAt;
    @PrePersist protected void onCreate() { this.createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String n) { this.name = n; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public String getPhone() { return phone; }
    public void setPhone(String p) { this.phone = p; }
    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String v) { this.vehicleNumber = v; }
    public String getLicenceNumber() { return licenceNumber; }
    public void setLicenceNumber(String l) { this.licenceNumber = l; }
    public String getAadhaarNumber() { return aadhaarNumber; }
    public void setAadhaarNumber(String a) { this.aadhaarNumber = a; }
    public boolean isAadhaarVerified() { return aadhaarVerified; }
    public void setAadhaarVerified(boolean v) { this.aadhaarVerified = v; }
    public WorkerStatus getStatus() { return status; }
    public void setStatus(WorkerStatus s) { this.status = s; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double r) { this.averageRating = r; }
    public int getTotalPickups() { return totalPickups; }
    public void setTotalPickups(int t) { this.totalPickups = t; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime c) { this.createdAt = c; }
}
