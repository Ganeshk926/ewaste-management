package com.ewaste.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ratings")
public class Rating {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long requestId;
    private Long workerId;
    private Long userId;
    private int rating;          // 1–5 stars
    private String feedback;
    private LocalDateTime createdAt;
    @PrePersist protected void onCreate() { this.createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getRequestId() { return requestId; }
    public void setRequestId(Long r) { this.requestId = r; }
    public Long getWorkerId() { return workerId; }
    public void setWorkerId(Long w) { this.workerId = w; }
    public Long getUserId() { return userId; }
    public void setUserId(Long u) { this.userId = u; }
    public int getRating() { return rating; }
    public void setRating(int r) { this.rating = r; }
    public String getFeedback() { return feedback; }
    public void setFeedback(String f) { this.feedback = f; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime c) { this.createdAt = c; }
}
