package com.ewaste.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "order_items")
public class OrderItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne @JoinColumn(name = "order_id")
    @com.fasterxml.jackson.annotation.JsonIgnore
    private Order order;
    private Long productId;
    private String productName;
    private double price;
    private int quantity;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Order getOrder() { return order; }
    public void setOrder(Order o) { this.order = o; }
    public Long getProductId() { return productId; }
    public void setProductId(Long p) { this.productId = p; }
    public String getProductName() { return productName; }
    public void setProductName(String n) { this.productName = n; }
    public double getPrice() { return price; }
    public void setPrice(double p) { this.price = p; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int q) { this.quantity = q; }
}
