package com.ewaste.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "cart_items")
public class CartItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private Long productId;
    private int quantity;
    @Transient private String productName;
    @Transient private double productPrice;
    @Transient private String productImageUrl;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long u) { this.userId = u; }
    public Long getProductId() { return productId; }
    public void setProductId(Long p) { this.productId = p; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int q) { this.quantity = q; }
    public String getProductName() { return productName; }
    public void setProductName(String n) { this.productName = n; }
    public double getProductPrice() { return productPrice; }
    public void setProductPrice(double p) { this.productPrice = p; }
    public String getProductImageUrl() { return productImageUrl; }
    public void setProductImageUrl(String i) { this.productImageUrl = i; }
}
