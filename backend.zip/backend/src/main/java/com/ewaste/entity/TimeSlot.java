package com.ewaste.entity;
import jakarta.persistence.*;
@Entity @Table(name = "time_slot_master")
public class TimeSlot {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String slotLabel;
    private String startTime;
    private String endTime;
    public Long getId(){return id;} public void setId(Long i){this.id=i;}
    public String getSlotLabel(){return slotLabel;} public void setSlotLabel(String s){this.slotLabel=s;}
    public String getStartTime(){return startTime;} public void setStartTime(String s){this.startTime=s;}
    public String getEndTime(){return endTime;} public void setEndTime(String s){this.endTime=s;}
}
