package com.ewaste.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "products")
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(columnDefinition = "TEXT")
    private String description;
    private double price;
    private double originalPrice;
    private String category;
    private String imageUrl;
    private int stock;
    private boolean isActive = true;
    private LocalDateTime createdAt;
    @PrePersist protected void onCreate() { this.createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String n) { this.name = n; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public double getPrice() { return price; }
    public void setPrice(double p) { this.price = p; }
    public double getOriginalPrice() { return originalPrice; }
    public void setOriginalPrice(double o) { this.originalPrice = o; }
    public String getCategory() { return category; }
    public void setCategory(String c) { this.category = c; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String i) { this.imageUrl = i; }
    public int getStock() { return stock; }
    public void setStock(int s) { this.stock = s; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean a) { this.isActive = a; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime c) { this.createdAt = c; }
}
